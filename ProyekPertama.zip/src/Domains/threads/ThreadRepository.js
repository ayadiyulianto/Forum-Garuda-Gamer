class ThreadRepository {
    async addThread(addThread) {
      throw new Error("THREAD_REPOSITORY.METHOD_NOT_IMPLEMENTED");
    }
  
    async verifyAvailableIdThread(id) {
      throw new Error("THREAD_REPOSITORY.METHOD_NOT_IMPLEMENTED");
    }
  
    async getThreadDetail(id) {
      throw new Error("THREAD_REPOSITORY.METHOD_NOT_IMPLEMENTED");
    }
  }
  
  module.exports = ThreadRepository;
  